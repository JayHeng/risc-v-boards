# README #

This repo is just the hacked version from the original freedom-e-sdk (from https://github.com/sifive/freedom-e-sdk)

Since the original freedom-e-sdk from https://github.com/sifive/freedom-e-sdk keep updating and may be unstable, the purpose of this repo is to use a reduced version of freedom-e-sdk to make it enough to be used by SI-RISCV/e200_opensource project to show the simple demo and keep it stable. 

Note: we will maitain another dedicated github repo (https://github.com/SI-RISCV/hbird-e-sdk) specially for the HummingBird-E200 software development.
